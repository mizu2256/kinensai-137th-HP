document.addEventListener('DOMContentLoaded', () => {
    const backgroundImages = document.querySelectorAll('.bg-image');
    const content = document.querySelector('.theme-info');
    const imageHeight = window.innerHeight / 2; // ビューポートの高さを1枚の画像の高さと仮定

    let currentIndex = 0;

    // 最初の画像をアクティブにする
    backgroundImages[currentIndex].classList.add('active');

    window.addEventListener('scroll', () => {
        // 現在のスクロール位置
        const scrollY = window.scrollY;

        // 各画像に対応するスクロール範囲を計算
        // 例:
        // 画像1: scrollY >= 0 && scrollY < imageHeight
        // 画像2: scrollY >= imageHeight && scrollY < imageHeight * 2
        // 画像3: scrollY >= imageHeight * 2 && scrollY < imageHeight * 3
        
        let newIndex = Math.floor(scrollY / imageHeight);

        // インデックスが範囲外にならないように調整
        if (newIndex >= backgroundImages.length) {
            newIndex = backgroundImages.length - 1;
        } else if (newIndex < 0) {
            newIndex = 0;
        }

        // 現在のインデックスと新しいインデックスが異なる場合にのみ切り替える
        if (newIndex !== currentIndex) {
            backgroundImages[currentIndex].classList.remove('active');
            backgroundImages[newIndex].classList.add('active');
            currentIndex = newIndex;
        }
    });
});